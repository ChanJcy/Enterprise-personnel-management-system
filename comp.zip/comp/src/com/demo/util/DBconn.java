package com.demo.util;

import java.sql.*;

public class DBconn{
    static String url="jdbc:mysql://localhost:3306/comp?useUnicode=true&characterEncoding=UTF-8&useSSL=false";
    static String user="root";
    static String paw="root";
    static Connection conn=null;
    static PreparedStatement ps=null;
    static ResultSet rs=null;

    public static void init(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            conn= DriverManager.getConnection(url, user, paw);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            System.out.println("int[SQL连接异常]");
            e.printStackTrace();
        }
    }
    public static int addUpDel(String sql){
        int i=0;
        try {
            PreparedStatement ps=conn.prepareStatement(sql);
            i=ps.executeUpdate();
        } catch (Exception e) {
            // TODO Auto-generated catch block
            System.out.println("sql增删改异常");
            e.printStackTrace();
        }

        return i;

    }

    public static ResultSet selectSql(String sql){
        try {
            ps=conn.prepareStatement(sql);
            rs=ps.executeQuery(sql);
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("sql查询异常");
            e.printStackTrace();
        }
        return rs;

    }

    public static void closeConn(){
        try {
            conn.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.out.println("sql关闭异常");
            e.printStackTrace();
        }
    }

}
