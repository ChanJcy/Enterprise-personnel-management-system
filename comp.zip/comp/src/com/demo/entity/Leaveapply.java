package com.demo.entity;

public class Leaveapply {
    public int id;
    public String userid;
    public String name;
    public String reason;
    public String s_d;
    public String e_d;
    public String days;
    public String result;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getS_d() {
        return s_d;
    }

    public void setS_d(String s_d) {
        this.s_d = s_d;
    }

    public String getE_d() {
        return e_d;
    }

    public void setE_d(String e_d) {
        this.e_d = e_d;
    }

    public String getDays() {
        return days;
    }

    public void setDays(String days) {
        this.days = days;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }
}
