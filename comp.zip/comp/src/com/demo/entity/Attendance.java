package com.demo.entity;

public class Attendance {
    public int id;
    public String userid;
    public String name;
    public String month;
    public int adsence;
    public int clockin;
    public int late;
    public int early;
    public int leave;
    public String one;
    public String two;
    public String three;
    public String four;
    public String five;
    public String six;
    public String seven;
    public String eight;
    public String nine;
    public String ten;
    public String eleven;
    public String twelve;
    public String thirteen;
    public String fourteen;
    public String fifteen;
    public String sixteen;
    public String seventeen;
    public String eighteen;
    public String nineteen;
    public String twenty;
    public String twentyo;
    public String twentyt;
    public String twentyth;
    public String twentyf;
    public String twentyfi;
    public String twentys;
    public String twentyse;
    public String twentye;
    public String twentyn;
    public String thirty;
    public String thirtyo;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public int getAdsence() {
        return adsence;
    }

    public void setAdsence(int adsence) {
        this.adsence = adsence;
    }

    public int getClockin() {
        return clockin;
    }

    public void setClockin(int clockin) {
        this.clockin = clockin;
    }

    public int getLate() {
        return late;
    }

    public void setLate(int late) {
        this.late = late;
    }

    public int getEarly() {
        return early;
    }

    public void setEarly(int early) {
        this.early = early;
    }

    public int getLeave() {
        return leave;
    }

    public void setLeave(int leave) {
        this.leave = leave;
    }

    public String getOne() {
        return one;
    }

    public void setOne(String one) {
        this.one = one;
    }

    public String getTwo() {
        return two;
    }

    public void setTwo(String two) {
        this.two = two;
    }

    public String getThree() {
        return three;
    }

    public void setThree(String three) {
        this.three = three;
    }

    public String getFour() {
        return four;
    }

    public void setFour(String four) {
        this.four = four;
    }

    public String getFive() {
        return five;
    }

    public void setFive(String five) {
        this.five = five;
    }

    public String getSix() {
        return six;
    }

    public void setSix(String six) {
        this.six = six;
    }

    public String getSeven() {
        return seven;
    }

    public void setSeven(String seven) {
        this.seven = seven;
    }

    public String getEight() {
        return eight;
    }

    public void setEight(String eight) {
        this.eight = eight;
    }

    public String getNine() {
        return nine;
    }

    public void setNine(String nine) {
        this.nine = nine;
    }

    public String getTen() {
        return ten;
    }

    public void setTen(String ten) {
        this.ten = ten;
    }

    public String getEleven() {
        return eleven;
    }

    public void setEleven(String eleven) {
        this.eleven = eleven;
    }

    public String getTwelve() {
        return twelve;
    }

    public void setTwelve(String twelve) {
        this.twelve = twelve;
    }

    public String getThirteen() {
        return thirteen;
    }

    public void setThirteen(String thirteen) {
        this.thirteen = thirteen;
    }

    public String getFourteen() {
        return fourteen;
    }

    public void setFourteen(String fourteen) {
        this.fourteen = fourteen;
    }

    public String getFifteen() {
        return fifteen;
    }

    public void setFifteen(String fifteen) {
        this.fifteen = fifteen;
    }

    public String getSixteen() {
        return sixteen;
    }

    public void setSixteen(String sixteen) {
        this.sixteen = sixteen;
    }

    public String getSeventeen() {
        return seventeen;
    }

    public void setSeventeen(String seventeen) {
        this.seventeen = seventeen;
    }

    public String getEighteen() {
        return eighteen;
    }

    public void setEighteen(String eighteen) {
        this.eighteen = eighteen;
    }

    public String getNineteen() {
        return nineteen;
    }

    public void setNineteen(String nineteen) {
        this.nineteen = nineteen;
    }

    public String getTwenty() {
        return twenty;
    }

    public void setTwenty(String twenty) {
        this.twenty = twenty;
    }

    public String getTwentyo() {
        return twentyo;
    }

    public void setTwentyo(String twentyo) {
        this.twentyo = twentyo;
    }

    public String getTwentyt() {
        return twentyt;
    }

    public void setTwentyt(String twentyt) {
        this.twentyt = twentyt;
    }

    public String getTwentyth() {
        return twentyth;
    }

    public void setTwentyth(String twentyth) {
        this.twentyth = twentyth;
    }

    public String getTwentyf() {
        return twentyf;
    }

    public void setTwentyf(String twentyf) {
        this.twentyf = twentyf;
    }

    public String getTwentyfi() {
        return twentyfi;
    }

    public void setTwentyfi(String twentyfi) {
        this.twentyfi = twentyfi;
    }

    public String getTwentys() {
        return twentys;
    }

    public void setTwentys(String twentys) {
        this.twentys = twentys;
    }

    public String getTwentyse() {
        return twentyse;
    }

    public void setTwentyse(String twentyse) {
        this.twentyse = twentyse;
    }

    public String getTwentye() {
        return twentye;
    }

    public void setTwentye(String twentye) {
        this.twentye = twentye;
    }

    public String getTwentyn() {
        return twentyn;
    }

    public void setTwentyn(String twentyn) {
        this.twentyn = twentyn;
    }

    public String getThirty() {
        return thirty;
    }

    public void setThirty(String thirty) {
        this.thirty = thirty;
    }

    public String getThirtyo() {
        return thirtyo;
    }

    public void setThirtyo(String thirtyo) {
        this.thirtyo = thirtyo;
    }
}
