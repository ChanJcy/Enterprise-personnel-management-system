package com.demo.entity;

import java.sql.Date;

public class Salary {
    public int id;
    public String userid;
    public String name;
    public String salary;
    public Date ppdate;
    public String prize;
    public String prizereason;
    public String penalty;
    public String penaltyreason;
    public String total;
    public Date payday;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public Date getPpdate() {
        return ppdate;
    }

    public void setPpdate(Date ppdate) {
        this.ppdate = ppdate;
    }

    public String getPrize() {
        return prize;
    }

    public void setPrize(String prize) {
        this.prize = prize;
    }

    public String getPrizereason() {
        return prizereason;
    }

    public void setPrizereason(String prizereason) {
        this.prizereason = prizereason;
    }

    public String getPenalty() {
        return penalty;
    }

    public void setPenalty(String penalty) {
        this.penalty = penalty;
    }

    public String getPenaltyreason() {
        return penaltyreason;
    }

    public void setPenaltyreason(String penaltyreason) {
        this.penaltyreason = penaltyreason;
    }

    public String getTotal() {
        return total;
    }

    public void setTotal(String total) {
        this.total = total;
    }

    public Date getPayday() {
        return payday;
    }

    public void setPayday(Date payday) {
        this.payday = payday;
    }
}
