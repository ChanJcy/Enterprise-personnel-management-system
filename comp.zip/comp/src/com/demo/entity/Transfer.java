package com.demo.entity;

import java.sql.Date;

public class Transfer {
    public int id;
    public String userid;
    public String name;
    public Date time;
    public String department_old;
    public String position_old;
    public String department_new;
    public String position_new;
    public String state;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUserid() {
        return userid;
    }

    public void setUserid(String userid) {
        this.userid = userid;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }

    public String getDepartment_old() {
        return department_old;
    }

    public void setDepartment_old(String department_old) {
        this.department_old = department_old;
    }

    public String getPosition_old() {
        return position_old;
    }

    public void setPosition_old(String position_old) {
        this.position_old = position_old;
    }

    public String getDepartment_new() {
        return department_new;
    }

    public void setDepartment_new(String department_new) {
        this.department_new = department_new;
    }

    public String getPosition_new() {
        return position_new;
    }

    public void setPosition_new(String position_new) {
        this.position_new = position_new;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
}
