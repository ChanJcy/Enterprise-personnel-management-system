package com.demo.dao;

import com.demo.entity.*;

import java.sql.Date;
import java.util.List;

public interface UserDao {
//    登录注册
    public boolean login(String userid,String password,String permission,String state);
    public boolean register(Employee employee);
//    修改密码
    public boolean updatepaw(String userid,String password);
//    匹配账号
    public boolean isUser(String userid);

//    管理员
    public List<Injury> getInjuryAll();//全部工伤记录
    public List<Salary> getPpAll();//全部奖惩、工资记录
    public List<Leaveapply> getLeaveApplyAll();//全部请假记录
    public List<Transfer> getTransferApplyAll();//全部调职记录
    public List<Dimissionapply> getDimissionApplyAll();//全部离职记录
    public List<Employee> getEmployeeAll();//全部员工信息
    public boolean updateLeaveApply(int id,String result);//请假管理
    public boolean updateTransferApply(int id,String state);//调职管理
    public boolean updateTrEmplApply(String userid,String department,String position);//调职后员工信息表部门职位
    public boolean updateDimissionApply(String userid,String result);//离职管理 离职申请表
    public boolean updateDiEmplApply(String userid,String state);//离职后在职状态  用户信息表
    public boolean updateEmployee(String userid, String name, String password, String sex,
                                  String position, String department, String permission,
                                  String school, String major, String email,
                                  String number, String address);
//    普通用户
    public Employee queryUser(String userid);//获取单个员工信息
    public boolean leaveApply(Leaveapply leaveapply);//请假申请
    public boolean transferApply(Transfer transferapply);//调职申请
    public boolean dimissionApply(Dimissionapply dimissionapply);//离职申请

//    按月份查询
    public Attendance getMonthAtt(String userid,String month);//个人单月份考勤记录
    public List<Attendance> getMonthAttAll(String month);//全部单月份考勤记录

//    按账号查询
    public List<Attendance> getUseridAtt(String userid);//个人考勤记录
    public List<Injury> getUseridInjury(String userid);//个人工伤记录
    public List<Salary> getUseridPp(String userid);//个人奖惩、工资记录
    public List<Leaveapply> getUseridLeaveApply(String userid);//个人请假记录
    public List<Transfer> getUseridTransferApply(String userid);//个人调职记录
    public List<Dimissionapply> getUseridDimissionApply(String userid);//个人调职记录

}
