package com.demo.dao;

import com.demo.entity.*;
import com.demo.util.DBconn;

import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements UserDao {
    @Override
        public boolean login(String userid, String password, String permission,String state) {
            // TODO Auto-generated method stub
            boolean flag=false;
            try {
                DBconn.init();
                ResultSet rs=DBconn.selectSql("select userid,password,permission,state from employee where userid='"+userid+"'");

                while(rs.next()){
                    if(rs.getString("userid").equals(userid)&&
                            rs.getString("password").equals(password)&&
                            rs.getString("permission").equals(permission)&&
                            rs.getString("state").equals(state)){
                        flag=true;
                    }
                }DBconn.closeConn();
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return flag;
        }

    @Override
    public boolean register(Employee employee) {
        boolean flag=false;
        DBconn.init();
        int i=DBconn.addUpDel("insert into employee" +
                "(userid,name,password,sex,position,department,permission,school,major,email,number,address,enterdate,state)"
                +"values('"+employee.getUserid()+"','"+employee.getName()+"','"+employee.getPassword()+"','"
                +employee.getSex()+"','"+employee.getPosition()+"','"+employee.getDepartment()+"','"+employee.getPermission()+"','"
                +employee.getSchool()+"','"
                +employee.getMajor()+"','"+employee.getEmail()+"','"
                +employee.getNumber()+"','"+employee.getAddress()+"','"
                +employee.getEnterdate()+"','"+employee.getState()+"')");

        if(i>0){
            flag=true;
        }

        DBconn.closeConn();
        return flag;
    }

    @Override
    public boolean updatepaw(String userid, String password) {
        boolean flag=false;
        DBconn.init();

        String sql="update employee set password='"+password+"' where userid="+userid;
        int i=DBconn.addUpDel(sql);
        if(i>0){
            flag=true;
        }

        DBconn.closeConn();
        return flag;
    }

    @Override
    public boolean isUser(String userid) {
        boolean flag=false;
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from employee where userid='"+userid+"'");

            while(rs.next()){
                if(rs.getString("userid").equals(userid)){
                    flag=true;
                }
            }DBconn.closeConn();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return flag;
    }


    @Override
    public List<Injury> getInjuryAll() {
        List<Injury> list=new ArrayList<Injury>();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from injury");

            while(rs.next()){
                Injury injury=new Injury();
                injury.setUserid(rs.getString("userid"));
                injury.setName(rs.getString("name"));
                injury.setTime(rs.getDate("time"));
                injury.setInjury(rs.getString("injury"));
                injury.setAccident(rs.getString("accident"));
                list.add(injury);
            }
            DBconn.closeConn();
            return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Salary> getPpAll() {
        List<Salary> list=new ArrayList<Salary>();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from salary");

            while(rs.next()){

                Salary salary=new Salary();
                salary.setUserid(rs.getString("userid"));
                salary.setName(rs.getString("name"));
                salary.setSalary(rs.getString("salary"));
                salary.setPpdate(rs.getDate("ppdate"));
                salary.setPrize(rs.getString("prize"));
                salary.setPrizereason(rs.getString("prizereason"));
                salary.setPenalty(rs.getString("penalty"));
                salary.setPenaltyreason(rs.getString("penaltyreason"));
                salary.setTotal(rs.getString("total"));
                salary.setPayday(rs.getDate("payday"));
                list.add(salary);
            }
            DBconn.closeConn();
            return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Leaveapply> getLeaveApplyAll() {
        List<Leaveapply> list=new ArrayList<Leaveapply>();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from leaveapply");

            while(rs.next()){
                Leaveapply leaveapply=new Leaveapply();
                leaveapply.setId(rs.getInt("id"));
                leaveapply.setUserid(rs.getString("userid"));
                leaveapply.setName(rs.getString("name"));
                leaveapply.setReason(rs.getString("reason"));
                leaveapply.setS_d(rs.getString("s_d"));
                leaveapply.setE_d(rs.getString("e_d"));
                leaveapply.setDays(rs.getString("days"));
                leaveapply.setResult(rs.getString("result"));
                list.add(leaveapply);
            }
            DBconn.closeConn();
            return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Transfer> getTransferApplyAll() {
        List<Transfer> list=new ArrayList<Transfer>();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from transfer");

            while(rs.next()){
                Transfer transferapply=new Transfer();
                transferapply.setId(rs.getInt("id"));
                transferapply.setUserid(rs.getString("userid"));
                transferapply.setName(rs.getString("name"));
                transferapply.setTime(rs.getDate("time"));
                transferapply.setDepartment_old(rs.getString("department_old"));
                transferapply.setPosition_old(rs.getString("position_old"));
                transferapply.setDepartment_new(rs.getString("department_new"));
                transferapply.setPosition_new(rs.getString("position_new"));
                transferapply.setState(rs.getString("state"));
                list.add(transferapply);
            }
            DBconn.closeConn();
            return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Dimissionapply> getDimissionApplyAll() {
        List<Dimissionapply> list=new ArrayList<Dimissionapply>();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from dimissionapply");

            while(rs.next()){
                Dimissionapply dimissionapply=new Dimissionapply();
                dimissionapply.setId(rs.getInt("id"));
                dimissionapply.setUserid(rs.getString("userid"));
                dimissionapply.setName(rs.getString("name"));
                dimissionapply.setDepartment(rs.getString("department"));
                dimissionapply.setPosition(rs.getString("position"));
                dimissionapply.setReason(rs.getString("reason"));
                dimissionapply.setResult(rs.getString("result"));
                list.add(dimissionapply);
            }
            DBconn.closeConn();
            return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }


    @Override
    public List<Employee> getEmployeeAll() {
        List<Employee> list=new ArrayList<Employee>();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from employee");

            while(rs.next()){
                Employee employee=new Employee();
                employee.setUserid(rs.getString("userid"));
                employee.setName(rs.getString("name"));
                employee.setPassword(rs.getString("password"));
                employee.setSex(rs.getString("sex"));
                employee.setPosition(rs.getString("position"));
                employee.setDepartment(rs.getString("department"));
                employee.setPermission(rs.getString("permission"));
                employee.setSchool(rs.getString("school"));
                employee.setMajor(rs.getString("major"));
                employee.setEmail(rs.getString("email"));
                employee.setNumber(rs.getString("number"));
                employee.setAddress(rs.getString("address"));
                list.add(employee);
            }
            DBconn.closeConn();
            return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean updateLeaveApply(int id,String result) {
        boolean flag=false;
        DBconn.init();
        String sql="update leaveapply set result='"+result+
                "'where id="+id;
        int i=DBconn.addUpDel(sql);
        if(i>0){
            flag=true;
        }
        DBconn.closeConn();
        return flag;
    }

    @Override
    public boolean updateTransferApply(int id, String state) {
        boolean flag=false;
        DBconn.init();
        String sql="update transfer set state='"+state+
                "' where id="+id;
        int i=DBconn.addUpDel(sql);
        if(i>0){
            flag=true;
        }
        DBconn.closeConn();
        return flag;
    }

    @Override
    public boolean updateTrEmplApply(String userid, String department, String position) {
        boolean flag=false;
        DBconn.init();
        String sql="update employee set department='"+department+
                "',position='"+position+
                "' where userid="+userid;
        int i=DBconn.addUpDel(sql);
        if(i>0){
            flag=true;
        }
        DBconn.closeConn();
        return flag;
    }

    @Override
    public boolean updateDimissionApply(String userid, String result) {
        boolean flag=false;
        DBconn.init();
        String sql="update dimissionapply set result='"+result+
                "' where userid="+userid;
        int i=DBconn.addUpDel(sql);
        if(i>0){
            flag=true;
        }
        DBconn.closeConn();
        return flag;
    }

    @Override
    public boolean updateDiEmplApply(String userid, String state) {
        boolean flag=false;
        DBconn.init();
        String sql="update employee set state='"+state+
                "' where userid="+userid;
        int i=DBconn.addUpDel(sql);
        if(i>0){
            flag=true;
        }
        DBconn.closeConn();
        return flag;
    }

    @Override
    public boolean updateEmployee(String userid, String name, String password,
                                  String sex, String position, String department,
                                  String permission, String school, String major,
                                  String email, String number, String address) {
        boolean flag=false;
        DBconn.init();
        String sql="update employee set name='"+name+
                "',password='"+password+
                "',sex='"+sex+
                "',position='"+position+
                "',department='"+department+
                "',position='"+position+
                "',permission='"+permission+
                "',school='"+school+
                "',major='"+major+
                "',email='"+email+
                "',number='"+number+
                "',address='"+address+
                "' where userid="+userid;
        int i=DBconn.addUpDel(sql);
        if(i>0){
            flag=true;
        }
        DBconn.closeConn();
        return flag;
    }


    @Override
    public Employee queryUser(String userid) {
        Employee employee=new Employee();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from employee where userid='"+userid+"'");

            if(rs.next()){
                employee.setUserid(rs.getString("userid"));
                employee.setName(rs.getString("name"));
                employee.setPassword(rs.getString("password"));
                employee.setSex(rs.getString("sex"));
                employee.setPosition(rs.getString("position"));
                employee.setDepartment(rs.getString("department"));
                employee.setPermission(rs.getString("permission"));
                employee.setSchool(rs.getString("school"));
                employee.setMajor(rs.getString("major"));
                employee.setEmail(rs.getString("email"));
                employee.setNumber(rs.getString("number"));
                employee.setAddress(rs.getString("address"));
            }

            DBconn.closeConn();
//			return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return employee;
    }


    @Override
    public boolean leaveApply(Leaveapply leaveapply) {
        boolean flag=false;
        DBconn.init();
        int i=DBconn.addUpDel("insert into leaveapply" +
                "(userid,name,reason,s_d,e_d,days,result)"
                +"values('"+leaveapply.getUserid()+"','"+leaveapply.getName()+"','"
                +leaveapply.getReason()+"','"+leaveapply.getS_d()+"','"+leaveapply.getE_d()+"','"
                +leaveapply.getDays()+"','"+leaveapply.getResult()+"')");

        if(i>0){
            flag=true;
        }

        DBconn.closeConn();
        return flag;
    }

    @Override
    public boolean transferApply(Transfer transferapply) {
        boolean flag=false;
        DBconn.init();
        int i=DBconn.addUpDel("insert into transfer" +
                "(userid,name,time,department_old,position_old,department_new,position_new,state)"
                +"values('"+transferapply.getUserid()+"','"+transferapply.getName()+"','"
                +transferapply.getTime()+"','"
                +transferapply.getDepartment_old()+"','"+transferapply.getPosition_old()+"','"
                +transferapply.getDepartment_new()+"','"+transferapply.getPosition_new()+"','"
                +transferapply.getState()+"')");

        if(i>0){
            flag=true;
        }

        DBconn.closeConn();
        return flag;
    }

    @Override
    public boolean dimissionApply(Dimissionapply dimissionapply) {
        boolean flag=false;
        DBconn.init();
        int i=DBconn.addUpDel("insert into dimissionapply" +
                "(userid,name,department,position,reason,result)"
                +"values('"+dimissionapply.getUserid()+"','"+dimissionapply.getName()+"','"
                +dimissionapply.getDepartment()+"','"+dimissionapply.getPosition()+"','"
                +dimissionapply.getReason()+"','"+dimissionapply.getResult()+"')");

        if(i>0){
            flag=true;
        }

        DBconn.closeConn();
        return flag;
    }


    @Override
    public Attendance getMonthAtt(String userid, String month) {
        Attendance attendance=new Attendance();
        try{
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from attendance where userid='"+userid+"'and month='"+month+"'");
            if (rs.next()){
                attendance.setUserid(rs.getString("userid"));
                attendance.setName(rs.getString("name"));
                attendance.setMonth(rs.getString("month"));
                attendance.setAdsence(rs.getInt("adsence"));
                attendance.setClockin(rs.getInt("clockin"));
                attendance.setLeave(rs.getInt("leave"));
                attendance.setLate(rs.getInt("late"));
                attendance.setEarly(rs.getInt("early"));
                attendance.setOne(rs.getString("one"));
                attendance.setTwo(rs.getString("two"));
                attendance.setThree(rs.getString("three"));
                attendance.setFour(rs.getString("four"));
                attendance.setFive(rs.getString("five"));
                attendance.setSix(rs.getString("six"));
                attendance.setSeven(rs.getString("seven"));
                attendance.setEight(rs.getString("eight"));
                attendance.setNine(rs.getString("nine"));
                attendance.setTen(rs.getString("ten"));
                attendance.setEleven(rs.getString("eleven"));
                attendance.setTwelve(rs.getString("twelve"));
                attendance.setThirteen(rs.getString("thirteen"));
                attendance.setFourteen(rs.getString("fourteen"));
                attendance.setFifteen(rs.getString("fifteen"));
                attendance.setSixteen(rs.getString("sixteen"));
                attendance.setSeventeen(rs.getString("seventeen"));
                attendance.setEighteen(rs.getString("eighteen"));
                attendance.setNineteen(rs.getString("nineteen"));
                attendance.setTwenty(rs.getString("twenty"));
                attendance.setTwentyo(rs.getString("twentyo"));
                attendance.setTwentyt(rs.getString("twentyt"));
                attendance.setTwentyth(rs.getString("twentyth"));
                attendance.setTwentyf(rs.getString("twentyf"));
                attendance.setTwentyfi(rs.getString("twentyfi"));
                attendance.setTwentys(rs.getString("twentys"));
                attendance.setTwentyse(rs.getString("twentyse"));
                attendance.setTwentye(rs.getString("twentye"));
                attendance.setTwentyn(rs.getString("twentyn"));
                attendance.setThirty(rs.getString("thirty"));
                attendance.setThirtyo(rs.getString("thirtyo"));
            }
            DBconn.closeConn();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return attendance;
    }

    @Override
    public List<Attendance> getMonthAttAll(String month) {
        List<Attendance> list=new ArrayList<Attendance>();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from attendance where month ='"+month+"'");

            while(rs.next()){
                Attendance attendance=new Attendance();
                attendance.setUserid(rs.getString("userid"));
                attendance.setName(rs.getString("name"));
                attendance.setMonth(rs.getString("month"));
                attendance.setClockin(rs.getInt("clockin"));
                attendance.setAdsence(rs.getInt("adsence"));
                attendance.setLate(rs.getInt("late"));
                attendance.setEarly(rs.getInt("early"));
                attendance.setLeave(rs.getInt("leave"));
                list.add(attendance);
            }
            DBconn.closeConn();
            return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Attendance> getUseridAtt(String userid) {
        List<Attendance> list=new ArrayList<Attendance>();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from attendance where userid='"+userid+"'");

            while(rs.next()){

                Attendance attendance=new Attendance();
                attendance.setUserid(rs.getString("userid"));
                attendance.setName(rs.getString("name"));
                attendance.setMonth(rs.getString("month"));
                attendance.setClockin(rs.getInt("clockin"));
                attendance.setAdsence(rs.getInt("adsence"));
                attendance.setLate(rs.getInt("late"));
                attendance.setEarly(rs.getInt("early"));
                attendance.setLeave(rs.getInt("leave"));
                attendance.setOne(rs.getString("one"));
                attendance.setTwo(rs.getString("two"));
                attendance.setThree(rs.getString("three"));
                attendance.setFour(rs.getString("four"));
                attendance.setFive(rs.getString("five"));
                attendance.setSix(rs.getString("six"));
                attendance.setSeven(rs.getString("seven"));
                attendance.setEight(rs.getString("eight"));
                attendance.setNine(rs.getString("nine"));
                attendance.setTen(rs.getString("ten"));
                attendance.setEleven(rs.getString("eleven"));
                attendance.setTwelve(rs.getString("twelve"));
                attendance.setThirteen(rs.getString("thirteen"));
                attendance.setFourteen(rs.getString("fourteen"));
                attendance.setFifteen(rs.getString("fifteen"));
                attendance.setSixteen(rs.getString("sixteen"));
                attendance.setSeventeen(rs.getString("seventeen"));
                attendance.setEighteen(rs.getString("eighteen"));
                attendance.setNineteen(rs.getString("nineteen"));
                attendance.setTwenty(rs.getString("twenty"));
                attendance.setTwentyo(rs.getString("twentyo"));
                attendance.setTwentyt(rs.getString("twentyt"));
                attendance.setTwentyth(rs.getString("twentyth"));
                attendance.setTwentyf(rs.getString("twentyf"));
                attendance.setTwentyfi(rs.getString("twentyfi"));
                attendance.setTwentys(rs.getString("twentys"));
                attendance.setTwentyse(rs.getString("twentyse"));
                attendance.setTwentye(rs.getString("twentye"));
                attendance.setTwentyn(rs.getString("twentyn"));
                attendance.setThirty(rs.getString("thirty"));
                attendance.setThirtyo(rs.getString("thirtyo"));
                list.add(attendance);
            }
            DBconn.closeConn();
            return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Injury> getUseridInjury(String userid) {
        List<Injury> list=new ArrayList<Injury>();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from injury where userid='"+userid+"'");

            while(rs.next()){

                Injury injury=new Injury();
                injury.setUserid(rs.getString("userid"));
                injury.setName(rs.getString("name"));
                injury.setTime(rs.getDate("time"));
                injury.setInjury(rs.getString("injury"));
                injury.setAccident(rs.getString("accident"));
                list.add(injury);
            }
            DBconn.closeConn();
            return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Salary> getUseridPp(String userid) {
        List<Salary> list=new ArrayList<Salary>();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from salary where userid='"+userid+"'");

            while(rs.next()){
                Salary salary=new Salary();
                salary.setUserid(rs.getString("userid"));
                salary.setName(rs.getString("name"));
                salary.setSalary(rs.getString("salary"));
                salary.setPpdate(rs.getDate("ppdate"));
                salary.setPrize(rs.getString("prize"));
                salary.setPrizereason(rs.getString("prizereason"));
                salary.setPenalty(rs.getString("penalty"));
                salary.setPenaltyreason(rs.getString("penaltyreason"));
                salary.setTotal(rs.getString("total"));
                salary.setPayday(rs.getDate("payday"));
                list.add(salary);
            }
            DBconn.closeConn();
            return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Leaveapply> getUseridLeaveApply(String userid) {
        List<Leaveapply> list=new ArrayList<Leaveapply>();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from leaveapply where userid='"+userid+"'");

            while(rs.next()){
                Leaveapply leaveapply=new Leaveapply();
                leaveapply.setId(rs.getInt("id"));
                leaveapply.setUserid(rs.getString("userid"));
                leaveapply.setName(rs.getString("name"));
                leaveapply.setReason(rs.getString("reason"));
                leaveapply.setS_d(rs.getString("s_d"));
                leaveapply.setE_d(rs.getString("e_d"));
                leaveapply.setDays(rs.getString("days"));
                leaveapply.setResult(rs.getString("result"));
                list.add(leaveapply);
            }
            DBconn.closeConn();
            return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Transfer> getUseridTransferApply(String userid) {
        List<Transfer> list=new ArrayList<Transfer>();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from transfer where userid='"+userid+"'");

            while(rs.next()){
                Transfer transferapply=new Transfer();
                transferapply.setId(rs.getInt("id"));
                transferapply.setUserid(rs.getString("userid"));
                transferapply.setName(rs.getString("name"));
                transferapply.setTime(rs.getDate("time"));
                transferapply.setDepartment_old(rs.getString("department_old"));
                transferapply.setPosition_old(rs.getString("position_old"));
                transferapply.setDepartment_new(rs.getString("department_new"));
                transferapply.setPosition_new(rs.getString("position_new"));
                transferapply.setState(rs.getString("state"));
                list.add(transferapply);
            }
            DBconn.closeConn();
            return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Dimissionapply> getUseridDimissionApply(String userid) {
        List<Dimissionapply> list=new ArrayList<Dimissionapply>();
        try {
            DBconn.init();
            ResultSet rs=DBconn.selectSql("select * from dimissionapply where userid='"+userid+"'");

            while(rs.next()){
                Dimissionapply dimissionapply=new Dimissionapply();
                dimissionapply.setUserid(rs.getString("userid"));
                dimissionapply.setName(rs.getString("name"));
                dimissionapply.setDepartment(rs.getString("department"));
                dimissionapply.setPosition(rs.getString("position"));
                dimissionapply.setReason(rs.getString("reason"));
                dimissionapply.setResult(rs.getString("result"));
                list.add(dimissionapply);
            }
            DBconn.closeConn();
            return list;
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return null;
    }


}

