package com.demo.servlet;

import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class UpdateEmplServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String u_userid=request.getParameter("u_userid");
        String u_name=request.getParameter("u_name");
        String u_password=request.getParameter("u_password");
        String u_sex=request.getParameter("u_sex");
        String u_department=request.getParameter("u_department");
        String u_position=request.getParameter("u_position");
        String u_permission=request.getParameter("u_permission");
        String u_school=request.getParameter("u_school");
        String u_major=request.getParameter("u_major");
        String u_email=request.getParameter("u_email");
        String u_number=request.getParameter("u_number");
        String u_address=request.getParameter("u_address");

        UserDao ud=new UserDaoImpl();
        ud.updateEmployee(u_userid,u_name,u_password,u_sex,u_position,u_department,u_permission,
                u_school,u_major,u_email,u_number,u_address);
        request.setAttribute("uemplerr", "修改成功！");
        request.setAttribute("location","u_personal");
        request.getRequestDispatcher("DownServlet").forward(request, response);

    }
}
