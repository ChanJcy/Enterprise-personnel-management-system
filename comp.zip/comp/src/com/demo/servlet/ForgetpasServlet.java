package com.demo.servlet;

import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;
import com.demo.entity.Employee;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ForgetpasServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String userid = request.getParameter("userid");
        String password = request.getParameter("password");
        String repassword = request.getParameter("repassword");

        UserDao ud=new UserDaoImpl();
//
//		忘记密码
        if(!ud.isUser(userid)){
            request.setAttribute("forgererr", "账号有误！");
            request.getRequestDispatcher("forgetpas.jsp").forward(request, response);
        }else if(password==null||"".equals(password)){
            request.setAttribute("forgererr", "密码不能为空！");
            request.getRequestDispatcher("forgetpas.jsp").forward(request, response);
        }
        else if(repassword==null||"".equals(repassword)){
            request.setAttribute("forgererr", "请确认密码！");
            request.getRequestDispatcher("forgetpas.jsp").forward(request, response);
        }else if(password!=null && repassword!=null && !repassword.equals(password)){
            request.setAttribute("forgererr", "两次密码不一致！");
            request.getRequestDispatcher("forgetpas.jsp").forward(request, response);
        }
        else {
            ud.updatepaw(userid, password);
            request.getRequestDispatcher("/login.jsp").forward(request, response);
        }
//
    }
}
