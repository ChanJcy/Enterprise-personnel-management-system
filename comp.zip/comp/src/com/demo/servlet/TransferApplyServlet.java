package com.demo.servlet;

import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;
import com.demo.entity.Transfer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Date;

public class TransferApplyServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String t_userid=request.getParameter("t_userid");
        String t_name=request.getParameter("t_name");
        Date time=new java.sql.Date(new java.util.Date().getTime());
        String department_old=request.getParameter("department_old");
        String position_old=request.getParameter("position_old");
        String department_new=request.getParameter("department_new");
        String position_new=request.getParameter("position_new");
        String state="审核中";

        Transfer transferApply=new Transfer();
        UserDao ud=new UserDaoImpl();

        if (!t_userid.equals(request.getSession().getAttribute("userid"))||
                !t_name.equals(request.getSession().getAttribute("name"))||
                !department_old.equals(request.getSession().getAttribute("department"))||
                !position_old.equals(request.getSession().getAttribute("position"))
        ){
            request.setAttribute("transferapplyerr", "信息有误！");
            request.setAttribute("location","transfer");
            request.getRequestDispatcher("DownServlet").forward(request, response);
        } else {
            transferApply.setUserid(t_userid);
            transferApply.setName(t_name);
            transferApply.setTime(time);
            transferApply.setDepartment_old(department_old);
            transferApply.setPosition_old(position_old);
            transferApply.setDepartment_new(department_new);
            transferApply.setPosition_new(position_new);
            transferApply.setState(state);
            ud.transferApply(transferApply);
            request.setAttribute("transferapplyerr", "提交成功！");
            request.setAttribute("location","transfer");
            request.getRequestDispatcher("DownServlet").forward(request, response);
        }
    }
}
