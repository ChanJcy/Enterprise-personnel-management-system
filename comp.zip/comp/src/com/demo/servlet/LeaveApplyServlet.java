package com.demo.servlet;

import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;
import com.demo.entity.Leaveapply;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class LeaveApplyServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String l_userid=request.getParameter("l_userid");
        String l_name=request.getParameter("l_name");
        String l_reason=request.getParameter("l_reason");
        String l_s_d=request.getParameter("l_s_d");
        String l_e_d=request.getParameter("l_e_d");
        String l_days=request.getParameter("l_days");
        String l_result="审核中";

        Leaveapply leaveapply=new Leaveapply();
        UserDao ud=new UserDaoImpl();

        if (!l_userid.equals(request.getSession().getAttribute("userid"))||
                !l_name.equals(request.getSession().getAttribute("name"))){
            request.setAttribute("leaveapplyerr", "信息有误！");
            request.setAttribute("location","leave");
            request.getRequestDispatcher("DownServlet").forward(request, response);
        }else if (!ud.leaveApply(leaveapply)){
                request.setAttribute("leaveapplyerr", "提交失败！");
                request.setAttribute("location","leave");
                request.getRequestDispatcher("DownServlet").forward(request, response);
//            }
        }else {
            leaveapply.setUserid(l_userid);
            leaveapply.setName(l_name);
            leaveapply.setReason(l_reason);
            leaveapply.setS_d(l_s_d);
            leaveapply.setE_d(l_e_d);
            leaveapply.setDays(l_days);
            leaveapply.setResult(l_result);
            ud.leaveApply(leaveapply);
            request.setAttribute("leaveapplyerr", "提交成功！");
                request.setAttribute("location","leave");
                request.getRequestDispatcher("DownServlet").forward(request, response);
        }



    }
}
