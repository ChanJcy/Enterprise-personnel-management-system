package com.demo.servlet;

import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;
import com.demo.entity.Dimissionapply;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class DimissionApplyServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String d_userid=request.getParameter("d_userid");
        String d_name=request.getParameter("d_name");
        String d_department=request.getParameter("d_department");
        String d_position=request.getParameter("d_position");
        String d_reason=request.getParameter("d_reason");
        String d_result="审核中";

        Dimissionapply dimissionapply=new Dimissionapply();
        UserDao ud=new UserDaoImpl();

        if (!d_userid.equals(request.getSession().getAttribute("userid"))||
                !d_name.equals(request.getSession().getAttribute("name"))||
                !d_department.equals(request.getSession().getAttribute("department"))||
                !d_position.equals(request.getSession().getAttribute("position"))){
            request.setAttribute("dimissionapplyerr", "信息有误！");
            request.setAttribute("location","dimission");
            request.getRequestDispatcher("DownServlet").forward(request, response);
        }else {
            dimissionapply.setUserid(d_userid);
            dimissionapply.setName(d_name);
            dimissionapply.setDepartment(d_department);
            dimissionapply.setPosition(d_position);
            dimissionapply.setReason(d_reason);
            dimissionapply.setResult(d_result);
            ud.dimissionApply(dimissionapply);
            request.setAttribute("dimissionapplyerr", "提交成功！");
            request.setAttribute("location","dimission");
            request.getRequestDispatcher("DownServlet").forward(request, response);
        }

    }
}
