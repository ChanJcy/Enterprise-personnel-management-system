package com.demo.servlet;

import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class AllMonthAtt extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
        String month_allatt=request.getParameter("month_allatt");

        UserDao ud=new UserDaoImpl();
        ud.getMonthAttAll(month_allatt);
        request.setAttribute("location","a_att");
        request.getRequestDispatcher("DownServlet").forward(request, response);
//        System.out.println(month_allatt);


    }
}
