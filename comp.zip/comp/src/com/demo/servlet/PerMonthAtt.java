package com.demo.servlet;

import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class PerMonthAtt extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
        String month_att=request.getParameter("month_att");
        String userid= (String) request.getSession().getAttribute("userid");

        UserDao ud=new UserDaoImpl();
        ud.getMonthAtt(userid,month_att);
        request.setAttribute("location","att");
        request.getRequestDispatcher("DownServlet").forward(request, response);
//        System.out.println(userid+month_att);


    }
}
