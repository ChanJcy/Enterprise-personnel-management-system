package com.demo.servlet;

import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;
import com.demo.entity.Employee;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.Date;

public class RegisterServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String r_userid = request.getParameter("r_userid");
        String r_name = request.getParameter("r_name");
        String r_password = request.getParameter("r_password");
        String r_sex = request.getParameter("r_sex");
        String r_department = request.getParameter("r_department");
        String r_position = request.getParameter("r_position");
        String r_permission="0";
        String r_school = request.getParameter("r_school");
        String r_major = request.getParameter("r_major");
        String r_email = request.getParameter("r_email");
        String r_number = request.getParameter("r_number");
        String r_address = request.getParameter("r_address");
        Date r_enterdate=new java.sql.Date(new java.util.Date().getTime());
        String r_state="在职";

        Employee employee=new Employee();
        employee.setUserid(r_userid);
        employee.setName(r_name);
        employee.setPassword(r_password);
        employee.setSex(r_sex);
        employee.setDepartment(r_department);
        employee.setPosition(r_position);
        employee.setPermission(r_permission);
        employee.setSchool(r_school);
        employee.setMajor(r_major);
        employee.setEmail(r_email);
        employee.setNumber(r_number);
        employee.setAddress(r_address);
        employee.setEnterdate((java.sql.Date) r_enterdate);
        employee.setState(r_state);
        UserDao ud=new UserDaoImpl();
        ud.register(employee);
        request.setAttribute("registererr", "提交成功！");
        request.setAttribute("location","register");
        request.getRequestDispatcher("DownServlet").forward(request, response);

    }

}
