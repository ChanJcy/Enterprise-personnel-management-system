package com.demo.servlet;

import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class DimissionManageServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");
        String dimission_id=request.getParameter("dimission_id");
        String dimission_result=request.getParameter("dimission_result");

        UserDao ud=new UserDaoImpl();
//        System.out.println(leave_id+"+jieguo:"+leave_result);
        ud.updateDimissionApply(dimission_id,dimission_result);
        request.setAttribute("location","m_dimission");
        request.getRequestDispatcher("DownServlet").forward(request, response);
    }
}
