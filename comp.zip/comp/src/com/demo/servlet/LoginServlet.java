package com.demo.servlet;

import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;
import com.demo.entity.Employee;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class LoginServlet extends HttpServlet{

    public void doGet(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
        doPost(request,response);
    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{

        String userid=request.getParameter("userid");
        String password=request.getParameter("password");
        String permission=request.getParameter("permission");
        String state="在职";
        String l_state="离职";
        HttpSession session=request.getSession();
        session.setAttribute("userid",userid);
        session.setAttribute("permission",permission);
        UserDao ud=new UserDaoImpl();
        UserDaoImpl dao=new UserDaoImpl();
        Employee queryempl=dao.queryUser(userid);
        session.setAttribute("name",queryempl.getName());
        session.setAttribute("password",queryempl.getPassword());
        session.setAttribute("department",queryempl.getDepartment());
        session.setAttribute("position",queryempl.getPosition());

//        登录
        if(ud.login(userid, password, permission,state)){
			request.setAttribute("error", "无误");
            session.setAttribute("userid",userid);
            request.getRequestDispatcher("DownServlet").forward(request, response);


        }
        else{
            response.sendRedirect("login.jsp");
            if(userid==""||"".equals(userid)||password==""||"".equals(password)){
                session.setAttribute("error", "账号或密码不能为空！");
            }
            else if (!ud.isUser(userid)){
                session.setAttribute("error", "账号有误！");
            }
            else if(ud.login(userid, password, permission,l_state)){
                session.setAttribute("error", "该账号已注销！");
            }
            else {
                session.setAttribute("error", "有误！");
            }
//            System.out.println("有误"+permission);
        }

    }
}
