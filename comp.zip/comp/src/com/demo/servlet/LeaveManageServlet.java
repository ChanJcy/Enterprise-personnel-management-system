package com.demo.servlet;

import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;
import com.demo.entity.Leaveapply;
import com.demo.util.DBconn;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class LeaveManageServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");


        UserDao ud=new UserDaoImpl();

        String leave_id=request.getParameter("leave_id");
        int le_id=0;

        try {
            le_id=Integer.parseInt(leave_id.trim());
        }catch (Exception e){
            e.printStackTrace();

        }
        String leave_result=request.getParameter("leave_result");
        ud.updateLeaveApply(le_id,leave_result);
        request.setAttribute("location","m_leave");
        request.getRequestDispatcher("DownServlet").forward(request, response);


    }
}
