package com.demo.servlet;

import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class ChangepasServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String c_userid = request.getParameter("c_userid");
        String c_password = request.getParameter("c_password");
        String c_newpassword = request.getParameter("c_newpassword");
        String c_repassword = request.getParameter("c_repassword");

        UserDao ud=new UserDaoImpl();
        request.setAttribute("changepawerr","");
        if (request.getSession().getAttribute("userid").equals(c_userid)&&
        request.getSession().getAttribute("password").equals(c_password)){
            if (c_newpassword==null||"".equals(c_newpassword)){
                request.setAttribute("changepawerr","新密码不能为空!");
                request.setAttribute("location","changepas");
                request.getRequestDispatcher("DownServlet").forward(request, response);
            }else if (c_repassword==null||"".equals(c_repassword)){
                request.setAttribute("changepawerr","确认密码不能为空!");
                request.setAttribute("location","changepas");
                request.getRequestDispatcher("DownServlet").forward(request, response);
            }else if (c_newpassword!=null&&c_repassword!=null&&!c_repassword.equals(c_newpassword)){
                request.setAttribute("changepawerr","两次密码不一致!");
                request.setAttribute("location","changepas");
                request.getRequestDispatcher("DownServlet").forward(request, response);
            }else {
                ud.updatepaw(c_userid,c_newpassword);
                request.setAttribute("changepawerr","修改成功!");
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        }else {
            request.setAttribute("changepawerr","账号或密码有误!");
            request.setAttribute("location","changepas");
            request.getRequestDispatcher("DownServlet").forward(request, response);
        }
    }
}
