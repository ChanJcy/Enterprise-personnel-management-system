package com.demo.servlet;

import com.demo.dao.UserDao;
import com.demo.dao.UserDaoImpl;
import com.demo.entity.Transfer;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

public class TransferManageServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doPost(request,response);
    }

    public void doPost(HttpServletRequest request,HttpServletResponse response) throws ServletException, IOException{
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        UserDao ud=new UserDaoImpl();

        String transfer_id=request.getParameter("transfer_id");
        int tr_id=0;

        try {
            tr_id=Integer.parseInt(transfer_id.trim());
        }catch (Exception e){
            e.printStackTrace();
//            le_id=Integer.parseInt(leave_id);

        }
        String transfer_state=request.getParameter("transfer_state");
        String department_new=request.getParameter("department_new");
        String position_new=request.getParameter("position_new");

//        System.out.println(leave_id+"+jieguo:"+leave_result);
        ud.updateTransferApply(tr_id,transfer_state);

        request.setAttribute("location","m_transfer");
        request.getRequestDispatcher("DownServlet").forward(request, response);

    }
}
